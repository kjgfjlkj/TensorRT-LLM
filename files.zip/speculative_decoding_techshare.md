# Speculative Decoding 投机采样技术全面解析

**LLM Inference Acceleration — From Theory to TRT-LLM Practice**

> 涵盖: Rejection Sampling · Draft Model · Medusa · EAGLE · MTP · Tree Attention · TRT-LLM
>
> 技术分享文档 · 2025

---

## 目录

1. [引言：为什么需要 Speculative Decoding](#1-引言为什么需要-speculative-decoding)
2. [核心算法：Modified Rejection Sampling](#2-核心算法modified-rejection-sampling)
3. [四大技术路线全景](#3-四大技术路线全景)
4. [性能分析与对比](#4-性能分析与对比)
5. [推理框架实现现状](#5-推理框架实现现状)
6. [2024–2025 最新进展与发展趋势](#6-20242025-最新进展与发展趋势)
7. [我的工作：TRT-LLM 上的投机采样开发（大纲）](#7-我的工作trt-llm-上的投机采样开发大纲)
8. [参考文献](#8-参考文献)

---

## 1. 引言：为什么需要 Speculative Decoding

LLM 推理的根本瓶颈在于自回归解码的 **memory-bound** 特性。每生成一个 token，GPU 需要将全部模型权重从 HBM 读入计算单元，而实际计算只占很小比例。这意味着 GPU 算力大量闲置，推理效率极低。

### 1.1 Memory-Bound 瓶颈与 Roofline 分析

以 7B 模型（FP16，14GB 权重）在 A100（2 TB/s bandwidth）上为例：加载权重需要 ~7ms，而实际计算仅需 ~0.1ms——**98% 的时间在等待内存读取**。从 roofline model 角度看，单 token decode 的 arithmetic intensity 约为 **1 FLOPs/byte**，而 A100 的 ridge point 在 ~30–150 FLOPs/byte，意味着解码处于深度 memory-bound 区域，GPU 算力大量闲置。

> **核心洞察**：既然 forward pass 的时间主要被权重加载主导，那么一次 forward pass 处理 K+1 个 token 的墙钟时间与处理 1 个 token 几乎相同。

Speculative decoding 的核心思想是：用轻量 draft model 快速生成 γ 个候选 token，target model 在一次 forward pass 中并行验证所有候选，将原本需要 γ 次串行 decode 的工作压缩到一次，从而充分利用闲置算力。

![图 1: Autoregressive Decoding vs Speculative Decoding 对比](speculative_decoding_images/01_overview.png)
*图 1: Autoregressive Decoding vs Speculative Decoding 对比*

---

## 2. 核心算法：Modified Rejection Sampling

该算法由 Leviathan et al.（Google Research, ICML 2023）和 Chen et al.（DeepMind, 2023）独立提出。每个 iteration 包含三步：

### 2.1 算法流程

**Step 1 — Draft Phase**：Draft model M_q 自回归生成 γ 个候选 token x₁, x₂, ..., x_γ，同时记录每个位置的分布 q_i(x)。

**Step 2 — Verification Phase**：Target model M_p 在单次 forward pass 中并行计算所有 γ+1 个位置的分布 p₁(x), p₂(x), ..., p_{γ+1}(x)。

**Step 3 — Accept/Reject**：从左到右依次验证每个候选 token。对于位置 i，以概率 `min(1, p_i(x_i) / q_i(x_i))` 接受。首个被拒绝的位置 n 之后，从修正分布 `p'(x) = norm(max(0, p(x) − q(x)))` 中重新采样一个 token。若全部 γ 个 token 均被接受，则额外从 p_{γ+1}(x) 中采样一个 bonus token。因此每次 iteration **至少产出 1 个、至多产出 γ+1 个**有效 token。

![图 2: Modified Rejection Sampling 算法流程与公式](speculative_decoding_images/02_rejection_sampling.png)
*图 2: Modified Rejection Sampling 算法流程与公式*

### 2.2 正确性证明：Lossless 保证

对于任意 token x'，其最终被采样的概率为：

```
P(x = x') = P(accepted, x = x') + P(rejected) × p'(x')
           = min(p(x'), q(x')) + [p(x') − min(p(x'), q(x'))]
           = p(x')
```

这个证明对**任意** draft distribution q(x) 成立，意味着无论 draft model 质量如何，输出分布都严格等于 target model 的分布。

> **关键结论**：Speculative decoding 是完全 **lossless** 的——这是其最强的理论保证。

### 2.3 Acceptance Rate 与 Speedup 的定量关系

定义 acceptance rate α = E[Σ_x min(p(x), q(x))]，即 draft 与 target 分布重叠面积的期望。在 i.i.d. 假设下，每次 iteration 产出的期望 token 数为：

$$E[\text{tokens}] = \frac{1 - \alpha^{\gamma+1}}{1 - \alpha}$$

定义 cost coefficient c = t_draft / t_target，则加速比为：

$$\text{Speedup} = \frac{1 - \alpha^{\gamma+1}}{(1 - \alpha)(\gamma c + 1)}$$

当 draft model 比 target 小两个数量级时，c < 0.05 近似为零。例如 α = 0.8, γ = 5 时，期望每次产出 3.69 个 token，加速比约 **2.5×–3×**。

实际中 acceptance rate 通常在 **0.5–0.9** 范围内。Temperature 对 α 影响显著：temp=0 时 α 比 temp=1 高约 **13 个百分点**。

---

## 3. 四大技术路线全景

![图 3: 四大技术路线及发展时间线](speculative_decoding_images/03_tech_roadmap.png)
*图 3: Speculative Decoding 四大技术路线及发展时间线*

### 3.1 Draft Model 方法与 Self-Drafting

#### 3.1.1 独立 Draft Model

最直接的方式是使用同系列的小模型作为 drafter，如 LLaMA-68M/160M 为 Vicuna-7B/13B 草拟。关键发现是 **draft model 的推理延迟比其语言建模能力更重要**——更快的 draft 往往比更"准"的 draft 带来更好的整体加速。值得注意的是，用 7B model 为 13B model 草拟反而会变慢，因为 draft 的开销过大。

**DistillSpec**（Zhou et al., ICLR 2024）通过 knowledge distillation 对齐 draft 与 target 的分布，在标准 SD 基础上额外提升 **10–45%** 的加速。**Online Speculative Decoding**（Liu et al., 2023）则在推理过程中持续用 target 的验证 logits 更新 draft model，使 acceptance rate 能适应 query 分布的变化。

#### 3.1.2 Self-Speculative Decoding

**Draft & Verify**（Zhang et al., ACL 2024）通过选择性跳过 target model 中间层来构建"精简版"作为 drafter，无需额外模型。

**LayerSkip**（Meta, ACL 2024）提出端到端方案：训练时使用 progressive layer dropout + 共享 early exit loss，推理时前 N 层做 draft（如 32 层模型的前 8 层），后续层做验证。核心优势是**共享 KV cache**——draft 与 verify 阶段复用同一份 cache，显著降低内存开销。在 CNN/DM summarization 上实现 **2.16×** 加速。

### 3.2 Medusa：多头并行预测

Medusa（Cai et al., ICML 2024）在 target model 的最后一层 hidden state 之上添加多个轻量 prediction head，每个 head 预测不同未来位置的 token。架构为**单层 residual MLP**，推荐配置 **5 个 Medusa head**。

![图 4: Medusa 架构——多头并行预测](speculative_decoding_images/04_medusa.png)
*图 4: Medusa 架构——多头并行预测*

**Medusa-1** 冻结 backbone 仅训练 heads，参数高效，结合 rejection sampling 保证 lossless，加速 **~2.2×**。**Medusa-2** 联合训练 backbone 和 heads，加速可达 **2.3–3.6×**。

候选验证使用 **tree-structured attention**：将各 head 的 top-k 候选通过 Cartesian product 组合成候选树，一次 forward pass 验证所有路径。

**主要局限**：各 head 独立预测，无法感知前序位置的采样结果——例如当位置 t+1 可能是"am"或"always"时，head 2 无法据此调整其 t+2 的预测，导致在 sampling（非 greedy）场景下准确率受限。Spec-Bench 评测显示，Medusa 在 7B 模型上加速 **2.4×**，但在 33B 模型上降至 ~2.0×，**随模型规模增大而退化**。

### 3.3 EAGLE 系列——Feature Space 中的自回归

#### 3.3.1 EAGLE (ICML 2024)：重新思考 Feature Uncertainty

EAGLE 的核心创新是将 draft 的自回归从 token space 搬到 **feature space**。其 draft model 是一个单层 transformer decoder layer，输入为 target model 倒数第二层的 feature vector 与已采样 token 的 embedding 的拼接，输出为预测的下一个 feature，再经 target model 冻结的 LM head 得到 token 概率。

![图 5: EAGLE 架构——Feature Space 自回归](speculative_decoding_images/05_eagle.png)
*图 5: EAGLE 架构——Feature Space 自回归 Draft*

与 Medusa 不同，EAGLE 在每步 draft 时都知道前一步实际采样的 token，因此能构建**一致的 causal chain**，从根本上解决了 Medusa 在 sampling 场景下的 inconsistency 问题。

训练极为轻量：draft head 参数量仅 **0.24B（7B target）到 0.99B（70B target）**，在 4×A100 上 1–2 天即可完成训练。在 Spec-Bench 上实现 **2.5×–3.0×** 一致加速，不随模型规模退化。

#### 3.3.2 EAGLE-2 (EMNLP 2024)：动态 Draft Tree

EAGLE-2 的核心观察是 acceptance rate 不仅与 position 相关，还**强依赖于 context**。它发现 EAGLE 的 draft model 天然 well-calibrated——其输出 confidence score 近似等于实际 acceptance probability。基于此，推理时**动态构建 draft tree**：用贪心策略优先扩展 cumulative confidence 最高的节点。对于确定性高的上下文，tree 很窄很深；对于不确定的上下文，tree 宽而浅。

EAGLE-2 **无需额外训练**，直接使用 EAGLE-1 的 draft model，仅修改 tree 构建策略。加速比达 **3.05×–4.26×**，比 EAGLE-1 快 20%–40%。

#### 3.3.3 EAGLE-3 (NeurIPS 2025)：当前 SOTA

EAGLE-3 做了两个关键改进：

1. 移除 feature prediction 约束，改用 **training-time test** 直接模拟推理过程
2. 用**多层 feature fusion**（low/mid/high-level）替代仅用 top layer feature

加速比达 **3.0×–6.5×**，比 EAGLE-2 再提升 20%–40%。更重要的是，EAGLE-3 是首个展示出 draft model 随训练数据增加**持续提升**的版本（此前版本会 plateau）。在 vLLM 中，EAGLE-3 在 batch size 高达 56 时仍优于无 speculative decoding 的 baseline。

### 3.4 Multi-Token Prediction 与 Tree-based Verification

#### 3.4.1 DeepSeek MTP：训练时植入 Speculative Decoding 能力

DeepSeek-V3（671B total / 37B activated）在预训练中引入 Multi-Token Prediction 作为辅助目标。与 Meta 的并行独立 head 设计不同，DeepSeek 使用 **D 个串行 MTP module**，维护完整的 causal chain：每个 module 将前一层的 hidden representation 与 ground-truth future token embedding 结合，经独立 transformer block 产出预测。

![图 6: DeepSeek MTP 架构——训练时植入 Speculative Decoding 能力](speculative_decoding_images/06_mtp.png)
*图 6: DeepSeek MTP 架构——训练时植入 Speculative Decoding 能力*

推理时，MTP module 可直接作为 draft model（NextN），仅 **14B 参数**（主模型 671B），首个 additional token 的 acceptance rate **超过 80%**，实现 **~1.8× TPS 加速**。SGLang 实测：16×H200 上，3-token MTP window 达 81.5 tok/s per rank（avg acceptance length 2.18），对比 baseline 的 51 tok/s，**输出吞吐提升达 60%**。

#### 3.4.2 SpecInfer 与 Tree Attention

![图 7: Tree Attention 多候选路径并行验证](speculative_decoding_images/09_tree_attention.png)
*图 7: Tree-based Verification 多候选路径并行验证示意*

**SpecInfer**（Miao et al., ASPLOS 2024）使用多个 small speculative model（SSM）的预测构建 token tree，通过定制的 tree attention mask 在单次 forward pass 中验证所有候选路径。相比 flat sequence speculation（52–57% 成功率），tree-based 方式将验证成功率提升到 **96–97%**。

**Sequoia**（CMU/Together AI, 2024）引入 dynamic programming 算法优化 tree 结构，在 A100 上实现 LLaMA2-7B **4.04×** 加速，在 offloading 场景下达到 **9.96×** 加速。

#### 3.4.3 Lookahead Decoding

Lookahead decoding（Fu et al., ICML 2024）将自回归解码重新表述为 **non-linear fixed-point system**，用 Jacobi iteration 并行求解。优势是**无需任何 draft model 或额外训练**，可直接应用于任何 LLM。在 MT-bench 和 HumanEval 上实现 **1.5×–2.3×** 加速。

#### 3.4.4 Staged Speculative Decoding

多级级联 draft 进一步降低延迟。**Cascade Speculative Drafting**（NeurIPS 2024）提出 vertical cascade（最小级使用 n-gram 模型）和 horizontal cascade（后位置 token 用更小 drafter），额外提升 **81%** 加速。

---

## 4. 性能分析与对比

### 4.1 各方法加速比对比

![图 8: 各方法加速比对比](speculative_decoding_images/07_performance.png)
*图 8: 各方法加速比对比（Spec-Bench, temp=0）*

| 方法 | Vicuna-7B | Vicuna-13B | LLaMA2-70B | 特点 |
|------|-----------|------------|------------|------|
| Speculative Sampling | ~1.8× | ~1.7× | ~2.0× | 需独立小模型 |
| Medusa | ~2.3× | ~2.0× | N/A | 随规模退化 |
| EAGLE | ~3.0× | ~3.0× | ~2.8× | 一致性好 |
| EAGLE-2 | ~3.3× | ~3.5× | ~3.0× | 动态 tree |
| **EAGLE-3** | **~4.5×** | **~4.5×** | **~3.5×** | **当前 SOTA** |
| DeepSeek MTP | N/A | N/A | ~1.8× | 训练时植入 |

### 4.2 任务类型对加速效果的显著影响

不同任务的 acceptance rate 差异很大：

- **Coding 和数学推理**是"甜点场景"——代码有大量可预测的 boilerplate、括号配对、缩进等模式。HumanEval（coding）的 acceptance rate 约 **0.8**
- **Summarization** 表现中等：XSum 约 **0.62**，但 CNN/DailyMail 因 prompt-output 高重叠，n-gram 方法可达 **2.8×**
- **Creative/diverse generation** 最具挑战性——输出分布更"平坦"，draft 与 target 的分布重叠面积小
- **Temperature 越高，acceptance rate 越低**——temp=0 vs temp=1 差距可达 13 个百分点

### 4.3 Batch Size 是最关键的部署考量

![图 9: Batch Size 对加速效果的影响](speculative_decoding_images/10_batch_size.png)
*图 9: Batch Size 对 Speculative Decoding 加速效果的影响（示意）*

Speculative decoding 在**低 batch size（1–4）**时效果最佳。随着 batch size 增大，GPU 算力逐渐饱和，speculative decoding 的额外开销反而会拖慢整体吞吐：

- EAGLE 在 vLLM：batch size=2 时加速 1.3×，但 batch size=48 时反而**降至 0.7×**
- EAGLE-3 扩展了有效范围（batch size 56 仍有收益），但根本 trade-off 依然存在
- 当前**没有任何框架支持按请求动态开关 speculation**

> **生产部署建议**：高并发场景应优先通过 continuous batching 提升吞吐，再在每个 batch 内部考虑 speculative decoding。

---

## 5. 推理框架实现现状

### 5.1 TensorRT-LLM

TRT-LLM 支持的 speculative decoding 方法最为齐全：Draft/Target、EAGLE-1/2/3、Medusa、ReDrafter、Lookahead、NGram、MTP（DeepSeek V3/R1）以及用户自定义 draft tokens。实现分为两种架构：

- **One-Model**：将 drafter 作为 submodule 嵌入，整个 draft loop 作为单个 CUDA graph 执行，极致低延迟。目前支持 EAGLE-3（Llama 4 Maverick）和 MTP（DeepSeek V3/R1）
- **Two-Model**：在 PyExecutor 中独立运行 draft model，更灵活，支持所有模型

性能数据：Llama 3.1 405B 在 4×H200 上实现 **3.6× 吞吐加速**；Llama 3.3 70B 在 1×H200（FP8）上实现 **3.55× 加速**。

### 5.2 vLLM

支持 Draft Model、N-gram、MLP Speculators、EAGLE-1/3 和 Medusa。值得注意的是 vLLM **放弃了 tree decoding**，仅支持 chain decoding——因为 tree decoding 在 batch size > 1 时性能快速退化。Red Hat 与 vLLM 团队联合发布的 **Speculators** 库标准化了 draft model 的训练、存储和集成流程。

### 5.3 SGLang

深度集成了 EAGLE-2/3、DeepSeek MTP 和 NGram，通过 **SpecForge** 项目提供 EAGLE-3 draft model 的完整训练框架。独特功能包括：基于 confidence 的动态 tree attention、FR-Spec、overlap scheduler。

### 5.4 框架对比

![图 10: 主流框架支持对比](speculative_decoding_images/08_frameworks.png)
*图 10: 主流推理框架对 Speculative Decoding 的支持对比*

| 能力 | TRT-LLM | vLLM | SGLang | HF Transformers |
|------|---------|------|--------|-----------------|
| EAGLE-3 | ✓ | ✓ | ✓ | ✗ |
| Medusa | ✓ | ✓ | ✗ | ✗ |
| DeepSeek MTP | ✓ | ✗ | ✓ | ✗ |
| Tree Attention | 有限 | ✗（已禁用） | ✓ | ✗ |
| Continuous Batching | ✓ | ✓ | ✓ | ✗（仅 batch=1） |
| Draft 训练工具 | ✗ | ✓（Speculators） | ✓（SpecForge） | ✗ |
| 最高报告加速比 | 3.6× | 4.9× | 4× | 3×（offload 10×） |

---

## 6. 2024–2025 最新进展与发展趋势

### 6.1 三个最重要的方向

**方向一：EAGLE-3 成为事实标准。** LMSYS 的 SpecForge 项目为主流模型（Llama 3/4、Qwen、DeepSeek）提供了标准化的 EAGLE-3 draft head 训练流程和预训练 checkpoints。Red Hat 的 Speculators 库实现了 HuggingFace 格式的标准存储和分发。生态成熟度已进入 production-ready 阶段。

**方向二：训练内嵌 MTP 成为大模型的新范式。** DeepSeek-V3/R1 证明了在预训练阶段就植入 MTP 能力的可行性——以仅 2% 的额外参数换取推理时 1.8× 加速和 >80% 的 acceptance rate，且 MTP module 可随时丢弃。预计更多大模型会在预训练中内置 MTP。

**方向三：与量化、长上下文、多模态的交叉融合。** Apple 的 QuantSpec 证明了 4-bit quantized KV cache 在 speculative decoding 中保持 >90% acceptance rate 的可行性。长上下文场景（LongSpec、MagicDec、TriForce）和多模态场景都在快速发展。

### 6.2 值得关注的新方法

- **REST**（NAACL 2024）：用 suffix array 检索替代 neural draft model，plug-and-play 无需训练，代码生成 **1.62–2.36×** 加速
- **CLLMs**（ICML 2024）：受 diffusion consistency model 启发，训练 LLM 直接做 Jacobi trajectory 到 fixed point 的映射，**2.4–3.4×** 加速
- **Yggdrasil**（2025）：hardware-aware latency-optimal tree decoding，比 SpecInfer/Sequoia 快 **~4×**
- **Speculative Decoding for Reasoning**：长 chain-of-thought 输出是 SD 的理想场景，n-gram 方法因高度重复的推理模式获得显著收益

### 6.3 工业界部署现状

- **Google**：在 Search AI Overviews 中使用 speculative decoding 降低延迟
- **Snowflake**：Arctic Inference 实现 agent 任务 **4× 端到端加速**
- **OpenAI**：推出 "Predicted Outputs" API 用于代码编辑
- **Anthropic**：披露了 "Fast Edit" 模式

生产中的主要挑战是高并发下的性能退化和 draft model 针对特定工作负载的调优需求。

---

## 7. 我的工作：TRT-LLM 上的投机采样开发（大纲）

> ↓ 以下为你的工作介绍部分的建议大纲，请根据实际工作内容填充。

### 7.1 工作背景与目标

【建议内容】描述你在 TRT-LLM 上做 speculative decoding 的动机、目标和范围。例如：是实现新的 draft model 集成、优化现有 EAGLE/Medusa/MTP 的实现、还是做全新的算法？关联到 TRT-LLM 的 One-Model vs Two-Model 架构选择。

### 7.2 技术方案设计

【建议内容】

- **架构设计**：Draft model 的选择、集成方式、与 TRT-LLM executor 的交互
- **KV Cache 管理**：Draft 和 target 之间的 KV cache 共享/分离策略
- **Batch Scheduling**：如何在 continuous batching 中处理 speculative requests
- **CUDA Graph / Kernel 优化**：Draft loop 的优化策略
- **Verification 算法实现**：Tree attention 或 chain verification 的选择

### 7.3 实现细节与挑战

【建议内容】描述实现过程中遇到的关键技术挑战和解决方案。例如：

- TRT-LLM 内部架构与 speculative decoding 的适配难点
- 性能调优的关键技巧（如 CUDA graph capture、memory management）
- 对 ML 编译背景的听众：可类比为"推测执行 + 回滚"机制的编译器优化

### 7.4 实验结果与性能数据

【建议内容】展示具体的性能数据：

- Acceptance rate 在不同任务/模型下的表现
- Speedup ratio 对比（vs baseline, vs 其他方法）
- Throughput / latency 在不同 batch size 下的表现
- 与 TRT-LLM 现有方法的对比

### 7.5 总结与未来工作

【建议内容】总结工作贡献，并提出后续计划：

- 当前工作的主要贡献和创新点
- 已知限制和可改进方向
- 未来工作计划：如 per-request 动态 speculation 开关、与量化的结合

---

## 8. 参考文献

1. Leviathan et al., "Fast Inference from Transformers via Speculative Decoding", ICML 2023
2. Chen et al., "Accelerating LLM Decoding with Speculative Sampling", DeepMind 2023
3. Cai et al., "Medusa: Simple LLM Inference Acceleration Framework with Multiple Decoding Heads", ICML 2024
4. Li et al., "EAGLE: Speculative Sampling Requires Rethinking Feature Uncertainty", ICML 2024
5. Li et al., "EAGLE-2: Faster Inference of Language Models with Dynamic Draft Trees", EMNLP 2024
6. Li et al., "EAGLE-3: Scaling up Inference Acceleration via Training-Time Test", NeurIPS 2025
7. DeepSeek-AI, "DeepSeek-V3 Technical Report", 2024
8. Miao et al., "SpecInfer: Accelerating LLM Serving with Tree-based Speculative Inference", ASPLOS 2024
9. Chen et al., "Sequoia: Scalable, Robust, and Hardware-aware Speculative Decoding", 2024
10. Fu et al., "Break the Sequential Dependency of LLM Inference Using Lookahead Decoding", ICML 2024
11. Elhoushi et al., "LayerSkip: Enabling Early Exit Inference and Self-Speculative Decoding", ACL 2024
12. Zhou et al., "DistillSpec: Improving Speculative Decoding via Knowledge Distillation", ICLR 2024
13. NVIDIA, "TensorRT-LLM Speculative Decoding Documentation", 2025
14. vLLM Team, "How Speculative Decoding Boosts vLLM Performance", 2024
15. LMSYS, "SpecForge: Accelerating Speculative Decoding Training for SGLang", 2025
