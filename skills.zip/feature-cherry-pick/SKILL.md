---
name: feature-cherry-pick
description: Cherry-pick a feature from a diverged upstream branch into a local branch with intelligent dependency analysis and conflict resolution. Use this skill when the user wants to backport, port, transplant, or cherry-pick a specific feature/commit/patch from an upstream repo that is hundreds or thousands of commits ahead. The skill analyzes what the target commits depend on, selects the minimal picking strategy (direct cherry-pick, dependency chain pick, or surgical code transplant), and uses AI reasoning to resolve conflicts correctly so the feature actually works. Trigger this skill whenever the user mentions cherry-pick with conflicts, backporting features across diverged branches, porting model support, picking patches with dependencies, or adapting upstream features to an older branch.
---

# Feature Cherry-Pick

You help port a specific feature from a diverged upstream branch into a local branch. The core challenge: the local branch may be thousands of commits behind, so a simple `git cherry-pick` will often fail with conflicts or missing dependencies.

## Step 0: Gather Information

Before doing anything, make sure you have:

1. **Target commit(s)**: SHAs of the feature to port (ask if not provided)
2. **Current branch**: usually already known from context
3. **Upstream remote/branch**: where the target commits live (e.g., `upstream/main`, `origin/main`)
4. **Feature description**: what the feature does (helps with conflict resolution judgment calls)

If the user gives a PR number or description but not SHAs, find them:
```bash
# Search by keyword in upstream log
git log upstream/main --oneline --grep="minimax" -20

# Or look at files changed
git log upstream/main --oneline -- tensorrt_llm/models/minimax.py
```

## Step 1: Pre-flight

Always start with a clean working tree and a safety branch:
```bash
git status  # must be clean
git stash   # if not clean

# Create a backup branch before touching anything
git checkout -b feature-port-backup-$(date +%Y%m%d)
git checkout -  # back to original branch
```

## Step 2: Discovery — What Does the Target Change?

Examine each target commit:
```bash
# What files does it touch?
git show <sha> --stat

# Full diff (read this carefully)
git show <sha>

# Is it already in local branch?
git log --oneline HEAD | grep <sha[:8]>
```

Build a mental model: what new files does it add? What existing files does it modify? What new functions/classes/imports does it reference?

## Step 3: Dependency Analysis

This is the most important step. For each file the target modifies, check how much it has diverged:
```bash
# How different is this file between local and upstream?
git diff HEAD upstream/main -- <file> | wc -l

# Find ALL commits between local and upstream that touch the same files
git log HEAD..upstream/main --oneline -- <file1> <file2> ...

# Check if a specific function/class that the target uses exists locally
grep -r "ClassName\|function_name" tensorrt_llm/
```

For each new function/class/import the target commit introduces or relies on, determine:
- **Already in local branch** → no action needed
- **Missing from local, added by a nearby upstream commit** → potential dependency to cherry-pick
- **Missing from local, and local uses a different API for the same thing** → adaptation needed

**Build a dependency list** with these categories:
- `CRITICAL`: Missing from local, required for the feature to compile/run
- `NICE-TO-HAVE`: Related improvements, not strictly needed
- `ADAPTED`: Local has equivalent functionality but with different API — needs adaptation

## Step 4: Choose a Strategy

Based on the dependency list:

### Strategy A — Direct Cherry-Pick
**When**: 0–2 critical dependencies missing, no major API changes
```bash
git cherry-pick -x <sha>
# Resolve any conflicts, then:
git cherry-pick --continue
```

### Strategy B — Dependency Chain Cherry-Pick
**When**: 3–15 critical dependencies, APIs are mostly compatible

Cherry-pick in topological order (oldest upstream commit first):
```bash
# Sort deps chronologically
git log --reverse <dep1-sha> <dep2-sha> <target-sha> --oneline

# Cherry-pick oldest first
git cherry-pick -x <dep1> <dep2> ... <target>
```

Only pick `CRITICAL` dependencies. Skip `NICE-TO-HAVE` — they'll cause unnecessary conflicts.

When conflicts arise mid-chain, resolve them (see Phase 5) and `git cherry-pick --continue`.

### Strategy C — Surgical Transplant
**When**: >15 critical dependencies, major API/structural changes in core files, or the dependency chain picks up large unrelated changes

Instead of cherry-picking, manually apply the feature's logic:

1. **Read the full diff** of the target commit(s) carefully
2. **For each new file** (e.g., a new model file): copy it and adapt imports/API calls to match local codebase
3. **For each modification to existing files**: apply the logical change directly using Edit tool, adapting to the local code structure
4. **Port CRITICAL dependencies inline** — if the feature calls a helper that doesn't exist locally, copy just that helper (don't cherry-pick the whole commit that introduced it)
5. **Skip infrastructure changes** — if the feature's commit also modifies build files, CI configs, or documentation, you usually don't need those

The goal is: the feature's *logic* lands in the local branch, adapted to work with local *infrastructure*.

**When surgical is better**: When the local branch has significantly refactored the areas the feature touches, a surgical transplant lets you navigate the structural differences deliberately rather than fighting through a cascade of conflicts.

## Step 5: Conflict Resolution

When `git cherry-pick` produces conflicts, address each one methodically. Never blindly accept one side.

**Read each conflict carefully:**
```
<<<<<<< HEAD           (your local version)
local code here
=======
upstream new code here
>>>>>>> <sha>          (what the cherry-pick brings)
```

**Common conflict patterns and resolutions:**

**Pattern A — Renamed/moved function:**
The upstream code calls `new_util_func()` but local has the same thing as `old_util_func()` or it lives in a different module. → Update the reference in the incoming code to use the local name/path.

**Pattern B — Changed function signature:**
Upstream calls `build_attention(q, k, v, scale=1.0)` but local's version is `build_attention(q, k, v)`. → Adapt the call to match local's signature (drop extra args, or add defaults).

**Pattern C — Structural reorganization:**
The upstream commit modifies a function that has been split into multiple functions locally, or moved to a different class. → Find the equivalent location in the local structure and apply the logical change there.

**Pattern D — Both sides modified the same block:**
Read both versions. Understand the *intent* of each change. Usually you want: local bug fixes preserved + upstream new feature added. Write a version that achieves both.

**Pattern E — Import/include conflicts:**
Take the union of both import lists, removing duplicates. Prefer local module paths.

After resolving all conflicts in a file:
```bash
git add <resolved-file>
# When all files are resolved:
git cherry-pick --continue
```

If a cherry-pick is too messy to resolve cleanly:
```bash
git cherry-pick --abort
# Switch to surgical approach for this commit
```

## Step 6: Validate the Feature

After completing the pick/transplant, verify the feature works:

```bash
# 1. Basic import check (Python)
python -c "from tensorrt_llm.models import <ModelName>; print('Import OK')"

# 2. Check if the new model registers itself correctly
python -c "
from tensorrt_llm.models.automodel import AutoModelForCausalLM
print([k for k in AutoModelForCausalLM._model_registry.keys() if '<model>' in k.lower()])
"

# 3. Run related unit tests
pytest tests/unittest/ -k "<feature_keyword>" -x -v

# 4. Quick instantiation test (no GPU needed for shape checks)
python -c "
from tensorrt_llm.models import <ModelName>Config
cfg = <ModelName>Config()
print('Config OK:', cfg)
"
```

If validation fails, diagnose:
- **ImportError**: Something wasn't ported — trace the import chain
- **AttributeError**: An API was adapted incorrectly — check the local class's actual attributes
- **TypeError**: Wrong function signature — check local vs upstream signature
- **Test failures**: Read the test failure carefully; often points to a missed adaptation

Fix issues and re-validate until the feature is working.

## Step 7: Final Commit

For surgical transplants or multi-commit cherry-picks, write a clear commit message:

```
[feat] Port <feature name> from upstream

Source: NVIDIA/TensorRT-LLM@<sha> (and deps: <dep-shas>)

Ported:
- <NewModelName>Config and <NewModelName>ForCausalLM
- Required utility: <UtilityName> from <sha>

Adaptations from original:
- Adapted attention kernel selection to local FlashAttention API
- Ported config validation, skipping upstream benchmark configs
- Updated KV cache API calls to match local interface

Not ported (not needed for core functionality):
- Benchmark configuration examples
- Documentation updates
- CI test list changes
```

## Key Principles

- **Analyze before touching**: Understand the dependency map before running any git commands
- **Be selective**: Only pick what's needed for the feature — extra commits bring extra conflicts
- **Adapt, don't fight**: When there's a structural mismatch, adapt the incoming code to fit local patterns rather than forcing the local code to match upstream
- **Preserve local fixes**: The local branch likely has bug fixes not in upstream — make sure conflict resolution keeps those
- **Test incrementally**: For long dependency chains, validate after each group of picks, not just at the end
- **Document adaptations**: Future maintainers need to know what was changed from the original and why
