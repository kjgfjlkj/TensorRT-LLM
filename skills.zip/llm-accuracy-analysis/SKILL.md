---
name: llm-accuracy-analysis
description: >
  Guides step-by-step debugging of numerical accuracy issues in TensorRT-LLM models.
  Use this skill whenever there is a precision mismatch, wrong output tokens, NaN/Inf values,
  or any suspicion that a model is producing incorrect results compared to a HuggingFace
  reference. Covers both the PyTorch backend (torch path) and the TRT backend (TensorRT engine path).
  Trigger on phrases like "精度问题", "accuracy issue", "output mismatch", "wrong results",
  "debug model", "compare tensors", "精度对比", "mark_output", "dump tensor", "layer mismatch".
---

# LLM Accuracy Analysis in TensorRT-LLM

This skill walks through localizing accuracy issues by comparing intermediate tensors against
HuggingFace Transformers (the ground truth reference). The workflow finds *which module* first
diverges, then digs deeper.

---

## Overview

```
HuggingFace Transformers (reference) ──┐
                                        ├── compare_tensors.py ──> divergence report
TRTLLM PyTorch / TRT backend   ────────┘
```

Two analysis paths:

| Path | Backend | Key Tool |
|------|---------|----------|
| A | PyTorch (`backend="pytorch"`) | `debug_hook.py` or custom hooks |
| B | TRT engine (`backend="tensorrt"`) | `tensor.mark_output()` + `--debug_mode` |

---

## Step 0: Prepare Reference (HuggingFace Transformers)

The HuggingFace model runs in full precision (fp32 or bf16) and dumps tensors at the same
granularity as the TRTLLM backend you are testing.

### 0.1 Copy and patch the HF model file

Do **not** edit the installed transformers library in-place. Instead:

```bash
# Find the HF model class file
python -c "import transformers; import os; print(os.path.dirname(transformers.__file__))"
# e.g. find modeling_llama.py under that path

cp <transformers_path>/models/llama/modeling_llama.py ./hf_modeling_ref.py
```

Patch `hf_modeling_ref.py` to dump tensors at the module boundaries you want to compare.
See `references/hf_dump_guide.md` for module-level patching patterns.

### 0.2 Run HF reference and dump tensors

```python
# hf_ref_run.py  (create this script for your model)
import sys, os, torch
sys.path.insert(0, ".")
import hf_modeling_ref as hf_mod   # patched copy

from transformers import AutoTokenizer, AutoConfig
import numpy as np

DUMP_DIR = os.environ.get("DUMP_DIR", "hf_dump")
DUMP_LAYERS = list(map(int, os.environ.get("DUMP_LAYERS", "0").split(",")))
os.makedirs(DUMP_DIR, exist_ok=True)

model_path = os.environ["MODEL_PATH"]
input_text = os.environ.get("INPUT_TEXT", "Hello world")

tokenizer = AutoTokenizer.from_pretrained(model_path)
input_ids = tokenizer(input_text, return_tensors="pt").input_ids.cuda()

# Load patched model class — replace class name to match your model
config = AutoConfig.from_pretrained(model_path)
model = hf_mod.LlamaForCausalLM(config)
model.load_state_dict(
    torch.load(f"{model_path}/pytorch_model.bin", map_location="cpu"), strict=False)
model = model.cuda().to(torch.bfloat16).eval()

with torch.no_grad():
    out = model(input_ids=input_ids, output_hidden_states=True)
```

> **Tip**: Use the same `input_ids` for both HF and TRTLLM runs. Save them:
> `np.save("input_ids.npy", input_ids.cpu().numpy())`

---

## Path A: PyTorch Backend Analysis

### A.1 Use the built-in debug hook (quickest approach)

TensorRT-LLM already has `tensorrt_llm/_torch/debug/debug_hook.py`.
It registers pre/post forward hooks on every module and saves tensors as `.pt` files.

```python
from tensorrt_llm._torch.debug.debug_hook import debug_mode

# After loading your LLM with PyTorch backend:
with torch.inference_mode(), debug_mode(model, dest_folder="trtllm_dump"):
    # run one forward pass with the SAME input_ids as HF reference
    logits = model.forward(input_ids, ...)

# Tensors are in trtllm_dump/rank0/*.pt
# Naming: "{loop_idx}.{ModuleClass}-{in/out}.{arg_name}.pt"
```

**Filtering to specific layers** — use the `filter` parameter or set env var before loading:

```python
import os
os.environ["TLLM_DEBUG_LAYERS"] = "0,1,3"   # custom env var (read in your filter)

class LayerIndexFilter:
    def __call__(self, module):
        # Only hook Attention and MLP in layers 0,1,3
        target_layers = [0, 1, 3]
        target_types = ("Attention", "MLP", "GatedMLP", "Embedding", "FusedMoE")
        idx = getattr(module, "layer_idx", None)
        return (idx in target_layers or idx is None) and \
               any(t in type(module).__name__ for t in target_types)

with debug_mode(model, dest_folder="trtllm_dump", filter=LayerIndexFilter()):
    ...
```

### A.2 Manual hook approach (fine-grained control)

If you need to instrument a specific submodule that the built-in hook does not capture well:

```python
import torch, os
import numpy as np

DUMP_DIR = os.environ.get("DUMP_DIR", "trtllm_dump")
DUMP_LAYERS = list(map(int, os.environ.get("DUMP_LAYERS", "0").split(",")))
os.makedirs(DUMP_DIR, exist_ok=True)
_counter = {}

def make_hook(name):
    def pre_hook(module, args, kwargs):
        if module.layer_idx not in DUMP_LAYERS:
            return
        for i, a in enumerate(args):
            if isinstance(a, torch.Tensor):
                np.save(f"{DUMP_DIR}/{name}_layer{module.layer_idx}_in_{i}.npy",
                        a.float().cpu().numpy())
    def post_hook(module, args, kwargs, output):
        if module.layer_idx not in DUMP_LAYERS:
            return
        out = output[0] if isinstance(output, (tuple, list)) else output
        if isinstance(out, torch.Tensor):
            np.save(f"{DUMP_DIR}/{name}_layer{module.layer_idx}_out.npy",
                    out.float().cpu().numpy())
    return pre_hook, post_hook

# Register on modules of interest
for name, mod in model.named_modules():
    if any(t in type(mod).__name__ for t in ("Attention", "MLP", "GatedMLP")):
        pre, post = make_hook(type(mod).__name__)
        mod.register_forward_pre_hook(pre, with_kwargs=True)
        mod.register_forward_hook(post, with_kwargs=True)
```

### A.3 DeepSeek-style models with sparse MoE layers

Some models (DeepSeek, Llama4, Qwen2-MoE) only have MoE in certain layers (e.g., layer index ≥ 4).
Set `DUMP_LAYERS` to include both a dense layer and a MoE layer for comparison:

```bash
DUMP_LAYERS=0,4 python your_run_script.py   # layer 0 = MLP, layer 4 = MoE
```

In the model definition (`tensorrt_llm/_torch/models/modeling_deepseekv3.py` etc.), the MoE module
is typically named `FusedMoE`, `DeepSeekV2MoE`, or similar — check with:

```python
for name, mod in model.named_modules():
    print(name, type(mod).__name__)
```

---

## Path B: TRT Engine Backend Analysis

### B.1 Locate the model definition

TRT backend models live in `tensorrt_llm/models/<model_name>/model.py`.
The forward function builds a TensorRT graph using TRTLLM tensor ops.

```bash
ls tensorrt_llm/models/llama/    # model.py, config.py, convert.py
```

### B.2 Add `mark_output()` calls

Edit `model.py` to mark intermediate tensors as engine outputs.
Find the module/layer whose output you want to inspect:

```python
# In LlamaDecoderLayer.forward() or similar
hidden_states = self.self_attn(hidden_states, ...)
# ↓ add this line to export attention output:
hidden_states.mark_output(f"attn_out_layer{self.layer_idx}", trt.float16)

hidden_states = self.mlp(hidden_states)
# ↓ export MLP output:
hidden_states.mark_output(f"mlp_out_layer{self.layer_idx}", trt.float16)
```

**Where to find the dtype**: use `self.config.dtype` or the tensor's own dtype attribute.

**Layer filtering**: wrap in a condition:

```python
import os
_debug_layers = list(map(int, os.environ.get("TRT_DEBUG_LAYERS", "0").split(",")))

if self.layer_idx in _debug_layers:
    hidden_states.mark_output(f"attn_out_layer{self.layer_idx}", self.config.dtype)
```

### B.3 Rebuild the engine

After editing `model.py`, rebuild the engine — this is required because `mark_output` is baked
into the TRT graph at build time.

```bash
# Typical rebuild command (adapt to your model/config):
python convert_checkpoint.py --model_dir <hf_model> --output_dir ./trt_ckpt
trtllm-build \
    --checkpoint_dir ./trt_ckpt \
    --output_dir ./trt_engine \
    --gemm_plugin float16
```

### B.4 Run with `--debug_mode` to capture outputs

```bash
python examples/run.py \
    --engine_dir ./trt_engine \
    --tokenizer_dir <hf_model> \
    --input_text "Hello world" \
    --use_py_session \
    --debug_mode \
    --output_npy outputs.npy \
    --output_logits_npy logits.npy
```

- `--use_py_session` enables the Python session which supports debug mode
- `--debug_mode` makes the engine export the `mark_output` tensors
- Additional outputs are saved as `.npy` alongside the main output

> Alternatively, use `trtllm.DebugConfig` in executor API:
> ```python
> debug_config = trtllm.DebugConfig(debug_tensor_names=["attn_out_layer0", "mlp_out_layer0"])
> executor = trtllm.Executor(engine_path, ..., debug_config=debug_config)
> tensors = executor.get_latest_debug_tensors()
> ```

---

## Step 3: Compare Tensors

Use `scripts/compare_tensors.py` (bundled) to compare dumps from HF vs TRTLLM.

```bash
python scripts/compare_tensors.py \
    --ref-dir hf_dump \
    --test-dir trtllm_dump \
    --pattern "attention" \
    --layer 0
```

The script prints:
- **Cosine similarity** (1.0 = identical direction)
- **Max absolute error** (MAE)
- **Relative error** (norm of diff / norm of ref)
- **SQNR** (signal-to-quantization-noise ratio, in dB) — useful for quantized models

See `references/comparison_guide.md` for interpreting results and thresholds.

---

## Debugging Workflow Summary

```
1. Pick a suspect area (embedding? first layer? last layer? logits?)
2. Dump HF reference tensors for that module range
3. Dump TRTLLM tensors (PyTorch path A or TRT path B)
4. Run compare_tensors.py → look for the first layer where similarity drops
5. Narrow down: if attn_out is fine but mlp_out is bad → problem in MLP
6. If layer 0 is fine but layer 4 is bad → MoE is the suspect
7. Zoom in: dump input/output of sub-modules inside the failing module
8. Check: dtype cast, quantization scale, kernel selection (attn_backend, moe_backend)
```

---

## Common Root Causes

| Symptom | Likely Cause |
|---------|-------------|
| Cosine similarity < 0.99 at layer 0 | Embedding weight load error, vocab parallel mismatch |
| Sudden drop at specific layer | Wrong layer index mapping, MoE routing mismatch |
| Gradual drift across all layers | Accumulation error from lower precision (fp16 vs bf16) |
| NaN/Inf from layer N onwards | Overflow in a kernel; check input magnitude before that layer |
| Output token IDs wrong but logits close | Sampling / repetition penalty mismatch, not a precision bug |
| MoE output diverges | Expert routing top-k differs, or expert weight parallel sharding |
| Attention diverges | RoPE base/scaling mismatch, causal mask difference |
