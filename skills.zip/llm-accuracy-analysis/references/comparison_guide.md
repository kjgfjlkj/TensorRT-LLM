# Tensor Comparison Interpretation Guide

## Metrics Explained

### Cosine Similarity
Measures the angle between two tensors treated as vectors. Independent of magnitude.
- **1.0**: Identical direction (perfect match)
- **0.9999+**: Extremely close — likely just floating-point rounding
- **0.999–0.9999**: Small divergence — may be acceptable for quantized models
- **0.99–0.999**: Noticeable divergence — warrants investigation
- **< 0.99**: Significant error — something is wrong

**Best for**: Catching direction changes from wrong kernel, wrong dtype, wrong weight.

### Relative Error (||ref - test|| / ||ref||)
Normalizes the error magnitude by the reference magnitude.
- **< 1e-4**: Essentially identical
- **1e-4 – 1e-3**: Very close (fp16 vs fp32 rounding)
- **1e-3 – 1e-2**: Moderate error (int8 quantization range)
- **> 1e-2**: Large error — likely a bug

**Best for**: Spotting magnitude scaling errors.

### Max Absolute Error
The single largest element-wise difference. Sensitive to outliers.
Use when diagnosing NaN/Inf propagation or single bad values.

### SQNR (Signal-to-Quantization-Noise Ratio)
Industry standard for evaluating quantization quality.
- **> 40 dB**: Excellent (fp16 ↔ fp32 level)
- **30–40 dB**: Good (fp8 quantization)
- **20–30 dB**: Acceptable (int4/int8 weight-only)
- **< 20 dB**: Poor — investigate

---

## Diagnosing from Comparison Results

### Pattern 1: All layers OK except one specific layer
```
embedding_out   ✓ cos=0.99999
attn_out_layer0 ✓ cos=0.99998
mlp_out_layer0  ✓ cos=0.99997
attn_out_layer1 ✗ cos=0.981    ← first failure
mlp_out_layer1  ✗ cos=0.963
attn_out_layer2 ✗ cos=0.921
```
**Diagnosis**: Bug is in layer 1's attention. Check:
- Attention kernel selection (`attn_backend` env var)
- RoPE base/scaling factor mismatch
- KV cache layout differences (NHWC vs NCHW)

### Pattern 2: Embedding layer fails
```
embedding_out   ✗ cos=0.800
attn_out_layer0 ✗ cos=0.720
```
**Diagnosis**: Embedding weight load error or vocabulary parallel sharding issue.
Check `vocab_size`, `TP` configuration, and `gather_output` settings.

### Pattern 3: Gradual degradation
```
attn_out_layer0  cos=0.99998
attn_out_layer4  cos=0.9998
attn_out_layer8  cos=0.999
attn_out_layer16 cos=0.99
```
**Diagnosis**: Accumulation of small fp16 rounding errors. This is often acceptable
for quantized models. Check if the final token IDs match — logit comparison matters more.

### Pattern 4: MoE layers fail, dense layers OK
```
mlp_out_layer0    ✓ cos=0.99999
mlp_out_layer3    ✓ cos=0.99998
moe_out_layer4    ✗ cos=0.850    ← first MoE layer
moe_out_layer8    ✗ cos=0.720
```
**Diagnosis**: MoE routing or expert computation differs.
Check:
- `top_k` setting
- Expert weight parallel sharding (EP)
- Router normalization (`renormalize=True/False`)
- DeepSeek-specific: `routed_scaling_factor`, `n_group`, `topk_group`

### Pattern 5: Logits fine, but wrong token output
```
logits  ✓ cos=0.9998
```
**Diagnosis**: NOT a precision issue. Check:
- Sampling parameters (temperature, top_p, top_k)
- Repetition penalty
- EOS token handling
- Greedy vs sampling mode

---

## Quick Command Reference

```bash
# Full directory comparison, sorted by worst cosine similarity
python scripts/compare_tensors.py \
    --ref-dir hf_dump --test-dir trtllm_dump \
    --sort-by cosine --top 10

# Compare only attention layers
python scripts/compare_tensors.py \
    --ref-dir hf_dump --test-dir trtllm_dump \
    --pattern attn

# Compare specific layer
python scripts/compare_tensors.py \
    --ref-dir hf_dump --test-dir trtllm_dump \
    --layer 4

# Set pass/fail threshold and save CSV
python scripts/compare_tensors.py \
    --ref-dir hf_dump --test-dir trtllm_dump \
    --cosine-thr 0.999 \
    --output-csv results.csv

# Single file comparison
python scripts/compare_tensors.py \
    --ref hf_dump/logits.npy \
    --test trtllm_dump/logits.npy
```

---

## Environment Variables Used by Dump Scripts

| Variable | Default | Description |
|----------|---------|-------------|
| `DUMP_DIR` | `hf_dump` / `trtllm_dump` | Output directory for tensor files |
| `DUMP_LAYERS` | `0` | Comma-separated layer indices to dump |
| `TRT_DEBUG_LAYERS` | `0` | Same for TRT backend mark_output filtering |

Set these consistently for both the HF reference run and the TRTLLM run
to ensure matching file names and layer coverage.
