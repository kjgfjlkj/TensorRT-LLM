# HuggingFace Transformer Model Patching Guide

This guide shows how to add tensor dump hooks to a copied HuggingFace model file
for use as the reference ground truth in accuracy analysis.

---

## General Pattern

Copy the model file and wrap the `forward()` methods of modules of interest with
`np.save()` calls. Do NOT use `output_hidden_states=True` alone — that only gives you
the decoder layer outputs, not sub-module (attention/MLP) outputs.

```python
import numpy as np, os, torch

_DUMP_DIR = os.environ.get("DUMP_DIR", "hf_dump")
_DUMP_LAYERS = set(map(int, os.environ.get("DUMP_LAYERS", "0").split(",")))
os.makedirs(_DUMP_DIR, exist_ok=True)


def _save(name, tensor):
    """Save a tensor as float32 numpy array."""
    if isinstance(tensor, torch.Tensor):
        np.save(f"{_DUMP_DIR}/{name}.npy", tensor.float().detach().cpu().numpy())
```

---

## Llama-style Models

Llama has `LlamaAttention`, `LlamaMLP`, and `LlamaDecoderLayer`.

### Patch `LlamaAttention.forward()`

Find the `forward` method and add saves around the attention output:

```python
class LlamaAttention(nn.Module):
    def forward(self, hidden_states, ...):
        # ---- PATCH START ----
        if self.layer_idx in _DUMP_LAYERS:
            _save(f"attn_in_layer{self.layer_idx}", hidden_states)
        # ---- PATCH END ----

        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)
        # ... existing attention code ...
        attn_output = self.o_proj(attn_output)

        # ---- PATCH START ----
        if self.layer_idx in _DUMP_LAYERS:
            _save(f"attn_out_layer{self.layer_idx}", attn_output)
        # ---- PATCH END ----

        return attn_output, attn_weights, past_key_value
```

### Patch `LlamaMLP.forward()`

```python
class LlamaMLP(nn.Module):
    def forward(self, x):
        # ---- PATCH START ----
        layer_idx = getattr(self, "_layer_idx", -1)
        if layer_idx in _DUMP_LAYERS:
            _save(f"mlp_in_layer{layer_idx}", x)
        # ---- PATCH END ----

        down_proj = self.down_proj(
            self.act_fn(self.gate_proj(x)) * self.up_proj(x))

        # ---- PATCH START ----
        if layer_idx in _DUMP_LAYERS:
            _save(f"mlp_out_layer{layer_idx}", down_proj)
        # ---- PATCH END ----

        return down_proj
```

> **Note**: `LlamaMLP` does not always store `layer_idx`. Set it manually after model load:
> ```python
> for i, layer in enumerate(model.model.layers):
>     layer.mlp._layer_idx = i
> ```

### Patch `LlamaDecoderLayer.forward()` for layer-level comparison

```python
class LlamaDecoderLayer(nn.Module):
    def forward(self, hidden_states, ...):
        # ---- PATCH START ----
        if self.self_attn.layer_idx in _DUMP_LAYERS:
            _save(f"decoder_layer_in_{self.self_attn.layer_idx}", hidden_states)
        # ---- PATCH END ----

        # ... existing code ...

        # ---- PATCH START ----
        if self.self_attn.layer_idx in _DUMP_LAYERS:
            _save(f"decoder_layer_out_{self.self_attn.layer_idx}", hidden_states)
        # ---- PATCH END ----

        return outputs
```

---

## Embedding Layer

Add at the start of `LlamaModel.forward()`:

```python
class LlamaModel(nn.Module):
    def forward(self, input_ids, ...):
        inputs_embeds = self.embed_tokens(input_ids)
        # ---- PATCH START ----
        _save("embedding_out", inputs_embeds)
        # ---- PATCH END ----
        hidden_states = inputs_embeds
        ...
```

---

## MoE Models (DeepSeek, Qwen2-MoE, Mixtral, Llama4-MoE)

### Mixtral `MixtralSparseMoeBlock.forward()`

```python
def forward(self, hidden_states):
    # ---- PATCH START ----
    layer_idx = getattr(self, "_layer_idx", -1)
    if layer_idx in _DUMP_LAYERS:
        _save(f"moe_in_layer{layer_idx}", hidden_states)
    # ---- PATCH END ----

    # ... existing routing and expert code ...

    # ---- PATCH START ----
    if layer_idx in _DUMP_LAYERS:
        _save(f"moe_out_layer{layer_idx}", final_hidden_states)
    # ---- PATCH END ----
    return final_hidden_states, router_logits
```

### DeepSeek V2/V3 `DeepseekV2MoE.forward()` or `MoEGate`

MoE routing affects output significantly. Dump both the router logits and the expert output:

```python
def forward(self, hidden_states):
    layer_idx = getattr(self, "_layer_idx", -1)
    # ... existing gate code ...
    topk_idx, topk_weight = self.gate(hidden_states)

    # ---- PATCH: dump routing decision ----
    if layer_idx in _DUMP_LAYERS:
        _save(f"moe_topk_idx_layer{layer_idx}", topk_idx)
        _save(f"moe_topk_weight_layer{layer_idx}", topk_weight)
    # ---- END PATCH ----

    # ... compute expert outputs ...
    y = self.moe_infer(hidden_states, topk_idx, topk_weight)

    # ---- PATCH ----
    if layer_idx in _DUMP_LAYERS:
        _save(f"moe_out_layer{layer_idx}", y)
    # ---- END PATCH ----
    return y
```

---

## Running the patched HF model

```python
# After loading model and patched classes:
import os
os.environ["DUMP_DIR"] = "hf_dump"
os.environ["DUMP_LAYERS"] = "0,4"  # layer 0 (MLP) and layer 4 (first MoE)

input_ids = np.load("input_ids.npy")
input_ids = torch.from_numpy(input_ids).cuda()

with torch.no_grad():
    outputs = model(input_ids=input_ids)
    np.save("hf_dump/logits.npy", outputs.logits.float().cpu().numpy())
```

---

## Naming Convention

To make `compare_tensors.py` work automatically with `--ref-dir` and `--test-dir`,
use the same file names in both `hf_dump/` and `trtllm_dump/`:

| HF tensor file | TRTLLM tensor file |
|----------------|-------------------|
| `attn_out_layer0.npy` | `attn_out_layer0.npy` (or `.pt`) |
| `mlp_out_layer0.npy` | `mlp_out_layer0.npy` |
| `moe_out_layer4.npy` | `moe_out_layer4.npy` |
| `embedding_out.npy` | `embedding_out.npy` |
| `logits.npy` | `logits.npy` |

---

## Thresholds for Pass/Fail

| Metric | Good | Warning | Fail |
|--------|------|---------|------|
| Cosine similarity | ≥ 0.9999 | 0.999–0.9999 | < 0.999 |
| Relative error | < 1e-3 | 1e-3 – 1e-2 | > 1e-2 |
| SQNR | > 40 dB | 25–40 dB | < 25 dB |

For **fp8 quantized** models: cosine ≥ 0.998, SQNR > 30 dB is acceptable.
For **int4 weight-only** models: cosine ≥ 0.99, SQNR > 20 dB is acceptable.
