#!/usr/bin/env python3
"""
Universal tensor comparison script for TensorRT-LLM accuracy analysis.

Compares tensors saved by HuggingFace reference runs against TensorRT-LLM
(PyTorch backend or TRT backend) to localize accuracy regressions.

Usage:
    # Compare all tensors in two directories
    python compare_tensors.py --ref-dir hf_dump --test-dir trtllm_dump

    # Filter to specific module name pattern
    python compare_tensors.py --ref-dir hf_dump --test-dir trtllm_dump --pattern attention

    # Load two specific numpy/pytorch files directly
    python compare_tensors.py --ref hf_dump/attn_out.npy --test trtllm_dump/attn_out.npy

    # Set thresholds and get a pass/fail summary
    python compare_tensors.py --ref-dir hf_dump --test-dir trtllm_dump --cosine-thr 0.999
"""

import argparse
import os
import sys
from pathlib import Path
from typing import Optional, Tuple
import numpy as np

# Optional: torch for loading .pt files
try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


def load_tensor(path: str) -> np.ndarray:
    """Load a tensor from .npy, .npz, or .pt file and return as float32 numpy array."""
    path = Path(path)
    if path.suffix == ".npy":
        arr = np.load(str(path), allow_pickle=True)
    elif path.suffix == ".npz":
        data = np.load(str(path), allow_pickle=True)
        keys = list(data.keys())
        if len(keys) == 1:
            arr = data[keys[0]]
        else:
            print(f"  [npz] Multiple keys: {keys}. Using first: {keys[0]}")
            arr = data[keys[0]]
    elif path.suffix == ".pt":
        if not HAS_TORCH:
            raise RuntimeError("torch is required to load .pt files")
        t = torch.load(str(path), map_location="cpu", weights_only=True)
        if isinstance(t, torch.Tensor):
            arr = t.float().numpy()
        else:
            raise ValueError(f"Expected Tensor in {path}, got {type(t)}")
    else:
        raise ValueError(f"Unsupported file extension: {path.suffix}")

    return arr.astype(np.float32).reshape(-1)


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity between two flat arrays."""
    a = a.flatten().astype(np.float64)
    b = b.flatten().astype(np.float64)
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    if denom < 1e-12:
        return 1.0 if np.allclose(a, b) else 0.0
    return float(np.dot(a, b) / denom)


def max_abs_error(ref: np.ndarray, test: np.ndarray) -> float:
    return float(np.max(np.abs(ref.flatten() - test.flatten())))


def mean_abs_error(ref: np.ndarray, test: np.ndarray) -> float:
    return float(np.mean(np.abs(ref.flatten() - test.flatten())))


def relative_error(ref: np.ndarray, test: np.ndarray) -> float:
    ref_norm = np.linalg.norm(ref.flatten().astype(np.float64))
    diff_norm = np.linalg.norm((ref.flatten() - test.flatten()).astype(np.float64))
    if ref_norm < 1e-12:
        return 0.0 if diff_norm < 1e-12 else float("inf")
    return float(diff_norm / ref_norm)


def sqnr_db(ref: np.ndarray, test: np.ndarray) -> float:
    """Signal-to-Quantization-Noise Ratio in dB. Higher is better (>30 dB is usually fine)."""
    signal_power = np.mean(ref.flatten().astype(np.float64) ** 2)
    noise_power = np.mean((ref.flatten() - test.flatten()).astype(np.float64) ** 2)
    if noise_power < 1e-30:
        return float("inf")
    if signal_power < 1e-30:
        return -float("inf")
    return float(10 * np.log10(signal_power / noise_power))


def compare_pair(ref_path: str, test_path: str, label: str = "",
                 cosine_thr: float = 0.0) -> dict:
    """Compare one pair of tensor files and return a metrics dict."""
    try:
        ref = load_tensor(ref_path)
        test = load_tensor(test_path)
    except Exception as e:
        return {"label": label, "error": str(e)}

    if ref.shape != test.shape:
        # Broadcast-safe reshape: flatten both and trim to min length for comparison
        min_len = min(ref.size, test.size)
        ref = ref.flatten()[:min_len]
        test = test.flatten()[:min_len]
        shape_warning = f"Shape mismatch: {np.load(ref_path, allow_pickle=True).shape} vs " \
                        f"{np.load(test_path, allow_pickle=True).shape} — comparing first {min_len} elements"
    else:
        shape_warning = None

    cos = cosine_similarity(ref, test)
    mae = mean_abs_error(ref, test)
    max_ae = max_abs_error(ref, test)
    rel = relative_error(ref, test)
    sqnr = sqnr_db(ref, test)

    metrics = {
        "label": label,
        "cosine": cos,
        "mae": mae,
        "max_abs_error": max_ae,
        "relative_error": rel,
        "sqnr_db": sqnr,
        "shape_warning": shape_warning,
        "passed_thr": cos >= cosine_thr if cosine_thr > 0 else None,
    }
    return metrics


def find_matching_pairs(ref_dir: str, test_dir: str, pattern: Optional[str] = None,
                        layer: Optional[int] = None):
    """
    Match files between ref_dir and test_dir by name.
    Returns list of (ref_path, test_path, label) tuples.

    Supports .npy, .npz, .pt files.
    Pattern filtering: only include files whose name contains the pattern string.
    Layer filtering: only include files whose name contains 'layer{N}'.
    """
    ref_dir = Path(ref_dir)
    test_dir = Path(test_dir)

    EXTS = {".npy", ".npz", ".pt"}
    ref_files = {f.name: f for f in ref_dir.rglob("*") if f.suffix in EXTS}
    test_files = {f.name: f for f in test_dir.rglob("*") if f.suffix in EXTS}

    common = sorted(set(ref_files) & set(test_files))

    if not common:
        # Try matching by stem (ignore suffix difference between .pt and .npy)
        ref_stems = {f.stem: f for f in ref_dir.rglob("*") if f.suffix in EXTS}
        test_stems = {f.stem: f for f in test_dir.rglob("*") if f.suffix in EXTS}
        common_stems = sorted(set(ref_stems) & set(test_stems))
        pairs = [(str(ref_stems[s]), str(test_stems[s]), s) for s in common_stems]
    else:
        pairs = [(str(ref_files[n]), str(test_files[n]), n) for n in common]

    if pattern:
        pairs = [(r, t, l) for r, t, l in pairs if pattern.lower() in l.lower()]
    if layer is not None:
        layer_tags = [f"layer{layer}", f"_{layer}_", f"-{layer}-"]
        pairs = [(r, t, l) for r, t, l in pairs
                 if any(tag in l for tag in layer_tags)]

    return pairs


def print_metrics(m: dict, verbose: bool = False):
    label = m.get("label", "")
    if "error" in m:
        print(f"  [ERROR] {label}: {m['error']}")
        return

    cos = m["cosine"]
    sqnr = m["sqnr_db"]
    rel = m["relative_error"]
    max_ae = m["max_abs_error"]
    passed = m.get("passed_thr")

    # Colour-code by cosine similarity
    if cos >= 0.9999:
        status = "✓ OK"
    elif cos >= 0.999:
        status = "~ WARN"
    else:
        status = "✗ FAIL"

    if passed is not None:
        status = ("✓" if passed else "✗") + f" (thr={m.get('cosine_thr','?')})"

    sqnr_str = f"{sqnr:.1f} dB" if sqnr != float("inf") else "∞ dB"
    print(f"  {status}  cos={cos:.6f}  rel_err={rel:.4e}  max_ae={max_ae:.4e}  "
          f"SQNR={sqnr_str}  | {label}")

    if m.get("shape_warning"):
        print(f"    ⚠ {m['shape_warning']}")


def main():
    parser = argparse.ArgumentParser(
        description="Compare reference vs test tensors for LLM accuracy analysis")

    # Single pair mode
    parser.add_argument("--ref", help="Reference tensor file (.npy/.pt)")
    parser.add_argument("--test", help="Test tensor file (.npy/.pt)")

    # Directory mode
    parser.add_argument("--ref-dir", help="Directory with reference tensors")
    parser.add_argument("--test-dir", help="Directory with test tensors")

    # Filters
    parser.add_argument("--pattern", help="Only compare files whose name contains this string")
    parser.add_argument("--layer", type=int, help="Only compare files for this layer index")

    # Thresholds
    parser.add_argument("--cosine-thr", type=float, default=0.0,
                        help="Cosine similarity threshold for pass/fail (0 = off)")

    # Output
    parser.add_argument("--verbose", action="store_true", help="Print extra details")
    parser.add_argument("--sort-by", choices=["cosine", "rel_error", "sqnr", "name"],
                        default="cosine", help="Sort results by this metric (ascending for errors)")
    parser.add_argument("--top", type=int, default=0,
                        help="Show only top-N worst results (0 = show all)")
    parser.add_argument("--output-csv", help="Save results to CSV file")

    args = parser.parse_args()

    results = []

    if args.ref and args.test:
        # Single file comparison
        m = compare_pair(args.ref, args.test, label=Path(args.ref).name,
                         cosine_thr=args.cosine_thr)
        results.append(m)
    elif args.ref_dir and args.test_dir:
        pairs = find_matching_pairs(args.ref_dir, args.test_dir,
                                    pattern=args.pattern, layer=args.layer)
        if not pairs:
            print(f"No matching tensor files found between '{args.ref_dir}' and '{args.test_dir}'")
            print("  Make sure both directories contain .npy, .npz, or .pt files with matching names.")
            sys.exit(1)
        print(f"Found {len(pairs)} matching tensor pair(s)\n")
        for ref_path, test_path, label in pairs:
            m = compare_pair(ref_path, test_path, label=label, cosine_thr=args.cosine_thr)
            results.append(m)
    else:
        parser.print_help()
        sys.exit(1)

    # Sort
    def sort_key(m):
        if "error" in m:
            return (1, 0)
        if args.sort_by == "cosine":
            return (0, m["cosine"])   # ascending = worst first
        elif args.sort_by == "rel_error":
            return (0, -m["relative_error"])  # descending = worst first
        elif args.sort_by == "sqnr":
            return (0, m["sqnr_db"])  # ascending = worst first
        return (0, m["label"])

    results.sort(key=sort_key)

    if args.top > 0:
        results = results[:args.top]

    print("=" * 80)
    print("TENSOR COMPARISON RESULTS")
    print("=" * 80)
    for m in results:
        print_metrics(m, verbose=args.verbose)

    # Summary
    ok = sum(1 for m in results if "error" not in m and m["cosine"] >= 0.9999)
    warn = sum(1 for m in results if "error" not in m and 0.999 <= m["cosine"] < 0.9999)
    fail = sum(1 for m in results if "error" not in m and m["cosine"] < 0.999)
    errors = sum(1 for m in results if "error" in m)

    print("=" * 80)
    print(f"Summary: {ok} OK  {warn} WARN  {fail} FAIL  {errors} ERROR  (total {len(results)})")

    if args.cosine_thr > 0:
        n_pass = sum(1 for m in results if m.get("passed_thr") is True)
        n_fail = sum(1 for m in results if m.get("passed_thr") is False)
        print(f"Threshold (cosine >= {args.cosine_thr}): {n_pass} pass, {n_fail} fail")

    # CSV output
    if args.output_csv:
        import csv
        with open(args.output_csv, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=[
                "label", "cosine", "mae", "max_abs_error", "relative_error", "sqnr_db", "error"])
            writer.writeheader()
            for m in results:
                writer.writerow({
                    "label": m.get("label", ""),
                    "cosine": m.get("cosine", ""),
                    "mae": m.get("mae", ""),
                    "max_abs_error": m.get("max_abs_error", ""),
                    "relative_error": m.get("relative_error", ""),
                    "sqnr_db": m.get("sqnr_db", ""),
                    "error": m.get("error", ""),
                })
        print(f"Results saved to {args.output_csv}")

    # Exit code
    if fail > 0 or errors > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
